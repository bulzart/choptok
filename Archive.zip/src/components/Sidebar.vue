<template>
    <div>
      <!-- Sidebar -->
      <div
        :class="[
          'fixed top-0 left-0 h-screen w-64 bg-gray-50/80 dark:bg-gray-800/80 backdrop-blur-sm text-gray-900 dark:text-white transition-all duration-300 ease-in-out z-50',
          { '-translate-x-full': !isOpen }
        ]"
      >
        <!-- Logo -->
        <div class="flex items-center justify-center space-x-2 py-6">
          <span class="text-3xl font-extrabold bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">ChopTok</span>
        </div>
  
        <!-- Nav Items -->
        <nav class="mt-6">
          <a
            v-for="item in navItems"
            :key="item.name"
            :href="item.href"
            class="block py-3 px-4 rounded-lg transition duration-200 hover:bg-primary/10 hover:text-primary dark:hover:text-secondary"
          >
            <span class="mr-2">{{ item.icon }}</span>
            {{ item.name }}
          </a>
        </nav>
      </div>
  
      <!-- Toggle Button -->
      <button
        @click="toggleSidebar"
        class="fixed top-4 left-4 p-2 rounded-md bg-gray-50/80 dark:bg-gray-800/80 backdrop-blur-sm text-gray-900 dark:text-white z-50 focus:outline-none focus:ring focus:ring-primary/50 transition-all duration-200 hover:bg-primary/10"
      >
        <svg
          class="w-6 h-6"
          fill="none"
          stroke="currentColor"
          viewBox="0 0 24 24"
          xmlns="http://www.w3.org/2000/svg"
        >
          <path
            stroke-linecap="round"
            stroke-linejoin="round"
            stroke-width="2"
            d="M4 6h16M4 12h16M4 18h16"
          ></path>
        </svg>
      </button>
    </div>
  </template>
  
  <script setup>
  import { ref } from 'vue'
  
  const isOpen = ref(false)
  const navItems = [
    { name: 'Dashboard', href: '#', icon: '📊' },
    { name: 'Upload', href: '#', icon: '📤' },
    { name: 'My Videos', href: '#', icon: '🎬' },
    { name: 'Analytics', href: '#', icon: '📈' },
    { name: 'Settings', href: '#', icon: '⚙️' },
  ]
  
  const toggleSidebar = () => {
    isOpen.value = !isOpen.value
  }
  </script>